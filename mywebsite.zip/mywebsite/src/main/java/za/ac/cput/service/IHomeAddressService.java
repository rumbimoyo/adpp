package za.ac.cput.service;

import za.ac.cput.domain.HomeAddress;

import java.util.List;

public interface IHomeAddressService extends IService<HomeAddress, Long> {
    List<HomeAddress> getAll();
    void delete(Long id);


}

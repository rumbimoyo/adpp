package za.ac.cput.factory;

import za.ac.cput.domain.HomeAddress;
import za.ac.cput.util.Helper;

import java.util.Random;

public class HomeAddressFactory {
    public static HomeAddress createHomeAddress(String streetNumber, String streetName, String suburb,String city,String province,String country,int postalCode ) {
   // Long addressId = new Random().nextLong(); // This causes Hibernate errors!

    if (Helper.isNullOrEmpty(streetNumber)|| Helper.isNullOrEmpty(streetName)|| Helper.isNullOrEmpty(suburb) || Helper.isNullOrEmpty(city) || Helper.isNullOrEmpty(province) || Helper.isNullOrEmpty(country))
        return null;

        return new HomeAddress.Builder()
               // .setAddressID(addressId)
                .setStreetNumber(streetNumber)
                .setStreetName(streetName)
                .setSuburb(suburb)
                .setCity(city)
                .setProvince(province)
                .setCountry(country)
                .setPostalCode(postalCode)
                .build();

    }
}

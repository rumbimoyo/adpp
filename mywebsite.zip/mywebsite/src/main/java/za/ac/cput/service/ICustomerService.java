package za.ac.cput.service;

import za.ac.cput.domain.Customer;

import java.util.List;
import java.util.Optional;

public interface ICustomerService extends IService<Customer,String>{
    List<Customer> getAll();
    void delete(String id);

    Optional<Customer> findByEmail(String email);
    List<Customer> findAllByFirstName(String firstName);
    List<Customer> findAllByLastName(String lastName);
    List<Customer> findAllByHomeAddress_City(String city);
    List<Customer> findByFirstNameAndLastName(String firstName, String lastName);

}

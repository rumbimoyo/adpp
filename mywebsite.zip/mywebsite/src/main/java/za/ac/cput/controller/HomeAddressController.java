package za.ac.cput.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.domain.HomeAddress;
import za.ac.cput.service.HomeAddressService;

import java.util.List;

@RestController
@RequestMapping("/HomeAddress")
public class HomeAddressController {
    private HomeAddressService service;
    @Autowired
    public HomeAddressController(HomeAddressService service) {
        this.service = service;
    }
    @PostMapping("/create")
    public HomeAddress create(@RequestBody HomeAddress homeAddress){
        return service.create(homeAddress);
    }

   @GetMapping("/read/{addressID}")
    public HomeAddress read(@PathVariable long addressID){
        return service.read(addressID);
   }
   @PutMapping("/update")
    public HomeAddress update(@RequestBody HomeAddress homeAddress){
        return service.update(homeAddress);
   }
   @DeleteMapping("/delete/{addressID}")
    public HomeAddress delete(@PathVariable long addressID){
          service.delete(addressID);
          return null;
   }
   @GetMapping("/getAll")
    public List<HomeAddress> getAll(){
        return service.getAll();
   }
}

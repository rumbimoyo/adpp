package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.Customer;
import za.ac.cput.repository.CustomerRepository;

import java.util.List;
import java.util.Optional;
@Service
public class CustomerService implements ICustomerService{
//   @Autowired
//    private static ICustomerService service;
    private CustomerRepository customerRepository;

    @Autowired
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public Customer create(Customer customer) {
        return this.customerRepository.save(customer);
    }

    @Override
    public Customer read(String id) {
        return this.customerRepository.findById(id).orElse(null);
    }

    @Override
    public Customer update(Customer customer) {
        return this.customerRepository.save(customer);
    }

    @Override
    public void delete(String id) {
        this.customerRepository.deleteById(id);
    }

    @Override
    public Optional<Customer> findByEmail(String email) {
        return this.customerRepository.findByEmail(email);
    }

    @Override
    public List<Customer> findAllByFirstName(String firstName) {
        return this.customerRepository.findAllByFirstName(firstName);
    }

    @Override
    public List<Customer> findAllByLastName(String lastName) {
        return this.customerRepository.findAllByLastName(lastName);
    }

    @Override
    public List<Customer> findAllByHomeAddress_City(String city) {
        return this.customerRepository.findAllByHomeAddress_City(city);
    }

    @Override
    public List<Customer> findByFirstNameAndLastName(String firstName, String lastName) {
        return this.customerRepository.findByFirstNameAndLastName(firstName, lastName);
    }


    @Override
    public List<Customer> getAll() {
        return this.customerRepository.findAll();
    }
}

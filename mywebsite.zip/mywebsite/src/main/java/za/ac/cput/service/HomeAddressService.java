package za.ac.cput.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.domain.HomeAddress;
import za.ac.cput.repository.HomeAddressRepository;

import java.util.List;

@Service
public class HomeAddressService implements IHomeAddressService {
//    @Autowired
//    private static ICustomerService service;

    private HomeAddressRepository homeAddressRepository;

    @Autowired
    public HomeAddressService(HomeAddressRepository homeAddressRepository) {
        this.homeAddressRepository = homeAddressRepository;
    }

    @Override
    public HomeAddress create(HomeAddress homeAddress) {
        return this.homeAddressRepository.save(homeAddress);
    }

    @Override
    public HomeAddress read(Long id) {
        return this.homeAddressRepository.findById(id).orElse(null);
    }

    @Override
    public HomeAddress update(HomeAddress homeAddress) {
        return this.homeAddressRepository.save(homeAddress);
    }

    @Override
    public void delete(Long id) {
   this.homeAddressRepository.deleteById(id);
    }
    @Override
    public List<HomeAddress> getAll() {
        return this.homeAddressRepository.findAll();
    }
}

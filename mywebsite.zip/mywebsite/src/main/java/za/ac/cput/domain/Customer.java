package za.ac.cput.domain;

import jakarta.persistence.*;

@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String customerID;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "home_address_id")

//    @ManyToMany
//    @JoinTable(name ="")
    private HomeAddress homeAddress;

    public void setHomeAddress(HomeAddress homeAddress) {
        this.homeAddress = homeAddress;
    }

    public Customer(){}
    // will put a builder constructor here
   public Customer(Builder builder) {
        this.customerID = builder.CustomerID;
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.phoneNumber = builder.phoneNumber;
        this.email = builder.email;
        this.homeAddress = builder.homeAddress;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public HomeAddress getHomeAddress() {
        return homeAddress;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "CustomerID='" + customerID + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", email='" + email + '\'' +
                ", homeAddress=" + homeAddress +
                '}';
    }
    public static class Builder{
        private String CustomerID;
        private String firstName;
        private String lastName;
        private String phoneNumber;
        private String email;
        private HomeAddress homeAddress;

        public Builder setCustomerID(String customerID) {
            CustomerID = customerID;
            return this;
        }

        public Builder setFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder setLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder setEmail(String email) {
            this.email = email;
            return this;
        }

        public Builder setHomeAddress(HomeAddress homeAddress) {
            this.homeAddress = homeAddress;
            return this;
        }

        public Builder copy(Customer customer) {
            this.CustomerID = customer.getCustomerID();
            this.firstName = customer.getFirstName();
            this.lastName = customer.getLastName();
            this.phoneNumber = customer.getPhoneNumber();
            this.email = customer.getEmail();
            this.homeAddress = customer.getHomeAddress();
            return this;
        }
        public Customer build() {
            return new Customer(this);
        }
    }
}

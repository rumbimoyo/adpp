package za.ac.cput.factory;

import za.ac.cput.domain.Customer;
import za.ac.cput.domain.HomeAddress;
import za.ac.cput.util.Helper;

public class CustomerFactory {
    public static Customer  createCustomer(String firstName, String lastName, String mobile, String email, HomeAddress homeAddress) {
        String customerID = Helper.generateId();
        if (Helper.isNullOrEmpty(firstName) || Helper.isNullOrEmpty(lastName) || Helper.isNullOrEmpty(mobile)|| homeAddress==null)
            return null;

        if (!Helper.isValidEmail(email))
            return null;

        return new Customer.Builder()

                .setCustomerID(customerID)
                .setFirstName(firstName)
                .setLastName(lastName)
                .setPhoneNumber(mobile)
                .setEmail(email)
                .setHomeAddress(homeAddress)
                .build();
    }
}

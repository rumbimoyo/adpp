package za.ac.cput.service;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import za.ac.cput.domain.Customer;
import za.ac.cput.domain.HomeAddress;
import za.ac.cput.factory.CustomerFactory;
import za.ac.cput.factory.HomeAddressFactory;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.MethodName.class)

class CustomerServiceTest {
    @Autowired
    private  HomeAddressService addressService;

    @Autowired
    private  CustomerService service;

    private static HomeAddress homeAddress, homeAddress1,homeAddress2,homeAddress3;
    private static Customer customer, customer1, customer2, customer3;


@BeforeAll
    void setUp() {
    homeAddress = HomeAddressFactory.createHomeAddress("1233 ", "wrong turn street", "woodstock", "capetown", "westerncape", "south africa", 12);
    homeAddress1 = HomeAddressFactory.createHomeAddress("12", "Nelson Mandela Street", "Langa", "Cape Town", "Western Cape", "South Africa", 7455);
    homeAddress2 = HomeAddressFactory.createHomeAddress("45", "Voortrekker Road", "Goodwood", "Cape Town", "Western Cape", "South Africa", 7460);
  homeAddress3 = HomeAddressFactory.createHomeAddress("88", "Main Street", "Soweto", "Johannesburg", "Gauteng", "South Africa", 1868);


//  // call the create method
//    HomeAddress createdAddress = addressService.create(homeAddress);
//    customer = CustomerFactory.createCustomer("sibahle", "shange", "0612345678", "sibahlengubane@56gmail.com", createdAddress);
//
//    // customer 1
//    HomeAddress createdAddress1 = addressService.create(homeAddress1);
//    customer1 = CustomerFactory.createCustomer("Lindiwe", "Mokoena", "0712345678", "lindiwe.mokoena@example.com", createdAddress1);
//
//    //customer 2
//    HomeAddress createdAddress2 = addressService.create(homeAddress2);
//    customer2 = CustomerFactory.createCustomer("Thabo", "Nkosi", "0723456789", "thabo.nkosi@example.com", createdAddress2);
//
//   //customer 3
//    HomeAddress createdAddress3 = addressService.create(homeAddress3);
//    customer3 = CustomerFactory.createCustomer("Thabo", "Shange", "073452623212", "thabo.shange@example.com", createdAddress3);
//

}
    @Test
    @Order(1)
    void a_create() {
   HomeAddress createdAddress = addressService.create(homeAddress);
    assertNotNull(createdAddress);
    System.out.println("Created: " + createdAddress);

    customer = CustomerFactory.createCustomer("sibahle", "shange", "0612345678",
            "sibahlengubane@56gmail.com", createdAddress);
    assertNotNull(customer);
    Customer created = service.create(customer);
    assertNotNull(created);
    System.out.println("Created: " + created);
///// ==============================================================================================================
HomeAddress createdAddress1 = addressService.create(homeAddress1);
        assertNotNull(createdAddress1);
        System.out.println("Created: " + createdAddress1);

        customer1 = CustomerFactory.createCustomer("Lindiwe", "Mokoena", "0712345678", "lindiwe.mokoena@example.com", createdAddress1);
        assertNotNull(customer1);

        Customer createdCustomer = service.create(customer1);
        assertNotNull(createdCustomer);
        System.out.println("Created: " + createdCustomer);

//
//        // Create additional HomeAddress and Customer objects
//        HomeAddress createdAddress1 = addressService.create(homeAddress1);
//        assertNotNull(createdAddress1);
//        System.out.println("Created: " + createdAddress1);
//
//        customer1 = CustomerFactory.createCustomer("Lindiwe", "Mokoena", "0712345678", "lindiwe.mokoena@example.com", createdAddress1);
//        Customer created1 = addressService.create(customer1);
//        assertNotNull(created1);
//        System.out.println("Created: " + created1);
//=============================================================================
        HomeAddress createdAddress2 = addressService.create(homeAddress2);
        assertNotNull(createdAddress2);
        System.out.println("Created: " + createdAddress2);

        customer2 = CustomerFactory.createCustomer("Thabo", "Nkosi", "0723456789", "thabo.nkosi@example.com", createdAddress2);
        assertNotNull(customer2);

        Customer createdCustomer2 = service.create(customer2);
        assertNotNull(createdCustomer2);
        System.out.println("Created: " + createdCustomer2);
//-===================================================
        HomeAddress createdAddress3 = addressService.create(homeAddress3);
        assertNotNull(createdAddress3);
        System.out.println("Created: " + createdAddress3);

        customer3 = CustomerFactory.createCustomer("Thabo", "Shange", "073452623212", "thabo.shange@example.com", createdAddress3);
        assertNotNull(customer3);

        Customer createdCustomer3 = service.create(customer3);
        assertNotNull(createdCustomer3);
        System.out.println("Created: " + createdCustomer3);
    }

    @Test
    @Order(2)
    void b_read() {
        Customer read = service.read(customer2.getCustomerID());
        assertNotNull(read);
        System.out.println("Read: " + read);
    }

    @Test
    @Order(3)
    void c_update() {
        Customer newcustomer = new Customer.Builder()
                .copy(customer).setFirstName("oshabeni").build();
        Customer updatedCustomer= service.update(newcustomer);
        assertNotNull(updatedCustomer);
        System.out.println("Updated: " + updatedCustomer);
    }

    @Test
      @Order(4)
    //@Disabled
    void d_delete() {
        service.delete(customer1.getCustomerID());
          assertNull(service.read(customer1.getCustomerID()));
        System.out.println("Deleted: " + customer1.getFirstName());

    }

//    @Test
//    void f_findByEmail() {
//        String email = "sibahlengubane@56gmail.com";
//        Optional<Customer> found = service.findByEmail(email);
//        assertNotNull(found);
//        System.out.println("Found: " + found);
//    }
    @Test
    void g_findAllByFirstName() {
        String firstName = "Thabo";
        List<Customer> findAllByFirstName = service.findAllByFirstName(firstName);
        assertNotNull(findAllByFirstName);
        for (Customer customer : findAllByFirstName) {
            System.out.println("Find All By First Name: " + customer);
        }
    }
    @Test
    void h_findAllByLastName() {
        String lastName = "Shange";
        List<Customer> findAllByLastName = service.findAllByLastName(lastName);
        assertNotNull(findAllByLastName);
        for (Customer customer : findAllByLastName) {
            System.out.println("Find All By Last Name: " + customer);
        }
    }
    @Test
    void i_findAllByHomeAddress() {
        String city = "Cape Town";
        List<Customer> findbyCity =  service.findAllByHomeAddress_City(city);
        assertNotNull(findbyCity);
        for (Customer customer : findbyCity) {
            System.out.println("Find All By Home Address: " + customer);
        }
    }


    @Test
    @Order(5)
    void e_getAll() {
        service.getAll();
        for(Customer cust: service.getAll()) {
            System.out.println("Get All: " + cust);
        }
    }

    @Test
    void i_findAllByFirstnameAndLastname() {
        String firstName = "Thabo";
        String lastName = "Shange";
        List<Customer> findByFirstAndLastName = service.findByFirstNameAndLastName(firstName, lastName);
        assertNotNull(findByFirstAndLastName);
        for (Customer customer : findByFirstAndLastName) {
            System.out.println("Find All By First And Last Name: " + customer);
        }
    }

}
package za.ac.cput.factory;

import org.junit.jupiter.api.Test;
import za.ac.cput.domain.Customer;
import za.ac.cput.domain.HomeAddress;

import static org.junit.jupiter.api.Assertions.*;

class CustomerFactoryTest {
  private static HomeAddress homeAddress = HomeAddressFactory.createHomeAddress("1233 ","wrong turn street","woodstock","capetown","westerncape","south africa",12);
  private static Customer customer = CustomerFactory.createCustomer("sibahle","shange","0612345678","sibahlengubane@56gmail.com",homeAddress);

    @Test
    void testCreateCustomer() {
        assertNotNull(customer);
        System.out.println(customer.toString());
    }
        @Test
        void testEmail() {
            assertNotNull(customer.getEmail());
        }
    }




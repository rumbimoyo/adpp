//package za.ac.cput.repository;
//
//import org.junit.jupiter.api.MethodOrderer;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.TestMethodOrder;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import za.ac.cput.domain.Customer;
//import za.ac.cput.domain.HomeAddress;
//import za.ac.cput.factory.CustomerFactory;
//import za.ac.cput.factory.HomeAddressFactory;
//
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.*;
//@SpringBootTest
//@TestMethodOrder(MethodOrderer.MethodName.class)
//class CustomerRepositoryTest {
//
//
//    @Autowired
//    private HomeAddressRepository homeAddressRepository;
//    private static HomeAddress homeAddress = HomeAddressFactory.createHomeAddress("1233 ", "wrong turn street", "woodstock", "capetown", "westerncape", "south africa", 12);
//    HomeAddress homeAddress1 = HomeAddressFactory.createHomeAddress("12", "Nelson Mandela Street", "Langa", "Cape Town", "Western Cape", "South Africa", 7455);
//    HomeAddress homeAddress2 = HomeAddressFactory.createHomeAddress("45", "Voortrekker Road", "Goodwood", "Cape Town", "Western Cape", "South Africa", 7460);
//    HomeAddress homeAddress3 = HomeAddressFactory.createHomeAddress("88", "Main Street", "Soweto", "Johannesburg", "Gauteng", "South Africa", 1868);
//    HomeAddress homeAddress4 = HomeAddressFactory.createHomeAddress("32", "Dr Pixley KaSeme Street", "Durban Central", "Durban", "KwaZulu-Natal", "South Africa", 4001);
//    HomeAddress homeAddress5 = HomeAddressFactory.createHomeAddress("101", "Steve Biko Avenue", "Hatfield", "Pretoria", "Gauteng", "South Africa", 8983);
//
//
//    @Autowired
//    private CustomerRepository customerRepository;
//    private static Customer customer, customer1, customer2, customer3, customer4;
//
//    @Test
//    public void a_create() {
//        // Create a new HomeAddress and Customer
//        HomeAddress createdAddress = homeAddressRepository.save(homeAddress);
//        assertNotNull(createdAddress);
//        System.out.println("Created: " + createdAddress);
//
//        customer = CustomerFactory.createCustomer("sibahle", "shange", "0612345678", "sibahlengubane@56gmail.com", createdAddress);
//
//        Customer created = customerRepository.save(customer);
//        assertNotNull(created);
//        System.out.println("Created: " + created);
//        // Create additional HomeAddress and Customer objects
//        HomeAddress createdAddress1 = homeAddressRepository.save(homeAddress1);
//        assertNotNull(createdAddress1);
//        System.out.println("Created: " + createdAddress1);
//
//        customer1 = CustomerFactory.createCustomer("Lindiwe", "Mokoena", "0712345678", "lindiwe.mokoena@example.com", createdAddress1);
//        Customer created1 = customerRepository.save(customer1);
//        assertNotNull(created1);
//        System.out.println("Created: " + created1);
//
//        // Create additional HomeAddress and Customer objects
//        HomeAddress createdAddress2 = homeAddressRepository.save(homeAddress2);
//        assertNotNull(createdAddress2);
//        System.out.println("Created: " + createdAddress2);
//
//        customer2 = CustomerFactory.createCustomer("Thabo", "Nkosi", "0723456789", "thabo.nkosi@example.com", createdAddress2);
//
//        Customer created2 = customerRepository.save(customer2);
//        assertNotNull(created2);
//        System.out.println("Created: " + created2);
//
//        // Create additional HomeAddress and Customer objects
//        HomeAddress createdAddress3 = homeAddressRepository.save(homeAddress3);
//        assertNotNull(createdAddress3);
//        System.out.println("Created: " + createdAddress3);
//
//        customer3 = CustomerFactory.createCustomer("Ayanda", "Zulu", "0734567890", "ayanda.zulu@example.com", createdAddress3);
//
//        Customer created3 = customerRepository.save(customer3);
//        assertNotNull(created3);
//        System.out.println("Created: " + created3);
//
//        // Create additional HomeAddress and Customer objects
//        HomeAddress createdAddress4 = homeAddressRepository.save(homeAddress4);
//        assertNotNull(createdAddress4);
//        System.out.println("Created: " + createdAddress4);
//
//        customer4 = CustomerFactory.createCustomer("Noluthando", "Petersen", "0745678901", "nolu.petersen@example.com", createdAddress4);
//
//        Customer created4 = customerRepository.save(customer4);
//        assertNotNull(created4);
//        System.out.println("Created: " + created4);
//    }
//
//    @Test
//    void b_read(){
//        Customer read = customerRepository.findById(customer.getCustomerID()).orElse(null);
//        assertNotNull(read);
//        System.out.println("Read: " + read);
//    }
//    @Test
//    void c_update(){
//       Customer newCustomer = new Customer.Builder().copy(customer)
//               .setFirstName("Zandile").build();
//       Customer updatedCustomer = customerRepository.save(newCustomer);
//         assertNotNull(updatedCustomer);
//        System.out.println("Updated: " + updatedCustomer);
//
//    }
//    @Test
//    void e_update1(){
//       HomeAddress existingAddress = homeAddressRepository.findById(homeAddress1.getAddressID()).orElse(null);
//        HomeAddress newAddress = new HomeAddress.Builder().copy(homeAddress1)
//                .setCountry("SISOSHABENI").build();
//        HomeAddress updatedAddress = homeAddressRepository.save(newAddress);
//        assertNotNull(updatedAddress.toString());
//    }
//    @Test
//    void d_delete(){
//        customerRepository.deleteById(customer.getCustomerID());
//        System.out.println("Deleted: " + customer.getCustomerID());
//
//    }
//    @Test
//    void f_getAll(){
//        List<Customer> customers = customerRepository.findAll();
//        System.out.println("Get All Customers: ");
//        for(Customer cust: customers){
//            System.out.println(cust);
//        }
//    }}
////    @Test
////    void g_FindbyEmail() {
////        Optional<Customer> customer1 = customerRepository.findByEmail("lindiwe.mokoena@example.com");
////        System.out.println("Find by Email: " + customer1.orElse(null));
////    }
////    @Test
////    void h_FindbyFirstName() {
////        Optional<Customer> customer = customerRepository.findByFirstName("sibahle");
////        System.out.println("Find by First Name: " + customer.orElse(null));  //should return null as i deleted sibahle
////    }}
//////    @Test
//////    void i_findBySameLastName(){
//////        List<Customer> customers = customerRepository.findBySameLastName("Mokoena");
//////        System.out.println("Find by Last Name: ");
//////        for (Customer customer : customers) {
//////            System.out.println(customer);
//////        }
//////    }
////}
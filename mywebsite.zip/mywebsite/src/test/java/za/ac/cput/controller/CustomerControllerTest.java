package za.ac.cput.controller;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import za.ac.cput.domain.Customer;
import za.ac.cput.domain.HomeAddress;
import za.ac.cput.factory.CustomerFactory;
import za.ac.cput.factory.HomeAddressFactory;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.MethodName.class)

class CustomerControllerTest {
  public  static Customer customer;
    public static HomeAddress address;
    @Autowired
    private TestRestTemplate restTemplate ;  // will call the CRUD(HTTPs) Methods
  private static final String BASE_URL = "http://localhost:8080/mywebsite/customer";

    @BeforeEach
    void setUp() {
        address = HomeAddressFactory.createHomeAddress("1233 ",
                "wrong turn street",
                "woodstock", "capetown",
                "westerncape", "south africa",
                12);
        customer = CustomerFactory.createCustomer("sibahle",
                "shange",
                "0612345678",
                 "sibahlengubane@56gmail.com",  address);
    }

    @Test
    void a_create() {
        System.out.println("Customer before creation: " + customer);
        assertNotNull(customer.getCustomerID(), "Customer ID should not be null before API call");


        String Url = BASE_URL + "/create";
        ResponseEntity<Customer> postResponse = this.restTemplate.postForEntity(Url, customer, Customer.class);
        assertNotNull(postResponse);
        Customer savedCustomer= postResponse.getBody();
        System.out.println("Customer after creation: " + savedCustomer);
        System.out.println("Customer before creation: " + customer);
        //HttpStatus statusCode = (HttpStatus) restResponse.getStatusCode();
        assertEquals(customer.getCustomerID(), savedCustomer.getCustomerID());
        System.out.println("saved Employee: " + savedCustomer);
       // System.out.println("Status Code: " + statusCode);

    }


    @Test
    void b_read() {
    }

    @Test
    void c_update() {
    }

    @Test
    void d_delete() {
    }

    @Test
    void e_getAll() {
    }
}